package com.mihirzalawadiya.expensemanager.model;

/**
 * Created by Administrator on 17/03/2018.
 */

public class Category {
    private int categoryID;
    private String categoryName;
    private String categoryType;

    public int getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(int categoryID) {
        this.categoryID = categoryID;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryType() {
        return categoryType;
    }

    public void setCategoryType(String categoryType) {
        this.categoryType = categoryType;
    }

    public String toString()
    {
        return( categoryName);
    }
}
