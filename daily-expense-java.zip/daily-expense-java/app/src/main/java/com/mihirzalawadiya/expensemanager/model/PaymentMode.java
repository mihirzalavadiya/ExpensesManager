package com.mihirzalawadiya.expensemanager.model;

/**
 * Created by Administrator on 19/03/2018.
 */

public class PaymentMode {
    private int modeID;
    private String modeName;

    public int getModeID() {
        return modeID;
    }

    public void setModeID(int modeID) {
        this.modeID = modeID;
    }

    public String getModeName() {
        return modeName;
    }

    public void setModeName(String modeName) {
        this.modeName = modeName;
    }

    @Override
    public String toString() {
        return modeName;
    }
}
