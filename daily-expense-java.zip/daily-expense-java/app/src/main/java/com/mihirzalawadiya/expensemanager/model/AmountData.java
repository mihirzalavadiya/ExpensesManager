package com.mihirzalawadiya.expensemanager.model;

/**
 * Created by Administrator on 21/03/2018.
 */

public class AmountData {
    private String categoty_name;
    private double amount;

    public String getCategoty_name() {
        return categoty_name;
    }

    public void setCategoty_name(String categoty_name) {
        this.categoty_name = categoty_name;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
